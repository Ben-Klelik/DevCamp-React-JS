import React, { Component } from 'react';
import moment from "moment";

export default class App extends Component {
  render() {
    return (
      <div className='app'>
        <h1>DevCamp Stuff</h1>
        <h2>{moment().format("h:m:s a")}</h2>
      </div>
    );
  }
}
